<?php
/**
 * Jewellery Financial Accounting
 *
 * Author: Siddhesh Patil
 * Date: 29-Sep-17
 * Time: 6:43 PM
 */

$app = require_once __DIR__ . '/../bootstrap/app.php';

$app->start();